const data= {
cardData:[
    {
        id:1,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:2,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:3,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:4,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    }
    ,
    {
        id:5,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    }
    ,
    {
        id:6,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:7,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:8,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:9,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:10,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:11,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:12,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    },
    {
        id:13,
        img:"https://source.unsplash.com/random",
        title:"Product detail",
        productName:"Product Name",
        desc:"Description Of Product"
    }
]
}

export default data;